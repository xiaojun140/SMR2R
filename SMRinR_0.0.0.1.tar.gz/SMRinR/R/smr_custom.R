
#' The function of running SMR in R cutomically
#'
#' @param ref The command of SMR software
#' @details
#' The demo code detailed in the test file
#'
#' @export runSMR_custom
runSMR_custom <- function(command){
  system(command)
}

